package gradebook;
/**
 * this class tests the gradebook class
 * @author hunegnaw
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GradebookTester {
	private GradeBook grade1;
	private GradeBook grade2;
	

	@BeforeEach
	void setUp() throws Exception {
		//create object of gradebook of size 5
		grade1=new GradeBook(5);
		grade2=new GradeBook(5);
		//call addScore method for the gradebook objects
		grade1.addScore(50.0);
		grade1.addScore(80.0);
		grade1.addScore(70.0);
		
		grade2.addScore(55.0);
		grade2.addScore(65.0);
		grade2.addScore(75.0);
	}

	@AfterEach
	void tearDown() throws Exception {
		//set the objects of gradebook to null
		grade1=null;
		grade2=null;
	}

	@Test
	void addScore() {
		// Use the toString method to compare the contents of what is in the scores array vs. what is expected to be in the scores array
	       assertTrue((grade1.toString()).equals("50.0 80.0 70.0 "));
	       assertTrue((grade2.toString()).equals("55.0 65.0 75.0 "));

	       // Compare the scoreSize to the expected number of scores entered.
	       assertEquals(3, grade1.getScoreSize(), 0.001);
	       assertEquals(3, grade2.getScoreSize(), 0.001);
	   }
	
@Test
public void testSum()
{
    // Compare what is returned by sum() to the expected sum of the scores entered.
    assertEquals(200.0, grade1.sum(), 0.0001);
    assertEquals(195.0, grade2.sum(), 0.0001);
}

@Test
public void testMinimum()
{
    // Compare what is returned by minimum() to the expected minimum of the scores entered.
    assertEquals(50.0, grade1.minimum(), 0.001);
    assertEquals(55.0, grade2.minimum(), 0.001);
}

@Test
public void testFinalScore()
{
    // Compare what is returned by finalScore() 
	//to the expected finalScore of the scores entered.
    assertEquals(150.0, grade1.finalScore(), 0.001);
    assertEquals(140.0, grade2.finalScore(), 0.001);
}
}
